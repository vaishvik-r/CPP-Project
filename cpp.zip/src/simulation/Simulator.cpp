#include "simulation/Simulator.h"

#include <stdexcept>
#include <string>

SimulationResult Simulator::simulate(
    Circuit& circuit,
    const std::vector<std::vector<bool>>& inputRows
) const {
    SimulationResult result;

    std::vector<std::string> inputNames;
    std::vector<std::string> outputNames;

    for (int i = 0; i < circuit.getInputCount(); ++i) {
        inputNames.push_back("I" + std::to_string(i));
    }

    for (int i = 0; i < circuit.getOutputCount(); ++i) {
        outputNames.push_back("O" + std::to_string(i));
    }

    result.setInputNames(inputNames);
    result.setOutputNames(outputNames);

    for (const auto& row : inputRows) {
        if (row.size() != static_cast<std::size_t>(circuit.getInputCount())) {
            throw std::invalid_argument("Input row has incorrect width");
        }

        for (std::size_t i = 0; i < row.size(); ++i) {
            circuit.setInput(i, row[i]);
        }

        circuit.evaluate();

        std::vector<bool> outputs;
        for (int i = 0; i < circuit.getOutputCount(); ++i) {
            outputs.push_back(circuit.getOutput(i));
        }

        result.addRow(row, outputs);
    }

    return result;
}
