# Testing

Build and run the test suite with:

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

The automated tests cover:

1. NAND truth table
2. NOR truth table
3. NOT truth table
4. AND truth table
5. OR truth table
6. XOR truth table
7. XNOR truth table
8. Half Adder
9. Full Adder
10. 4-bit Ripple Carry Adder
11. Generic simulation
12. Truth-table generation
13. CSV output
