#ifndef FULL_ADDER_H
#define FULL_ADDER_H
#include "core/Circuit.h"
#include "circuits/HalfAdder.h"
#include "gates/ORGate.h"
class FullAdder : public Circuit {
public: FullAdder();
};
#endif
