#ifndef HALF_ADDER_H
#define HALF_ADDER_H
#include "core/Circuit.h"
#include "gates/XORGate.h"
#include "gates/ANDGate.h"
class HalfAdder : public Circuit {
public: HalfAdder();
};
#endif
