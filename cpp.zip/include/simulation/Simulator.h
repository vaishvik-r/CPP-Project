#ifndef SIMULATOR_H
#define SIMULATOR_H

#include "core/Circuit.h"
#include "simulation/SimulationResult.h"

#include <vector>

class Simulator {
public:
    SimulationResult simulate(
        Circuit& circuit,
        const std::vector<std::vector<bool>>& inputRows
    ) const;
};

#endif
