#ifndef TRUTH_TABLE_GENERATOR_H
#define TRUTH_TABLE_GENERATOR_H

#include "core/Circuit.h"
#include "simulation/SimulationResult.h"

class TruthTableGenerator {
public:
    SimulationResult generate(Circuit& circuit) const;
};

#endif
