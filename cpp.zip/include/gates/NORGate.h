#ifndef NOR_GATE_H
#define NOR_GATE_H
#include "core/Gate.h"
class NORGate : public Gate {
public:
    NORGate();
    void evaluate() override;
};
#endif
