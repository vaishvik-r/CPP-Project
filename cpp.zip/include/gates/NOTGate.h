#ifndef NOT_GATE_H
#define NOT_GATE_H

#include "core/Gate.h"
#include "gates/NANDGate.h"

class NOTGate : public Gate {
public:
    NOTGate();
    void evaluate() override;

private:
    NANDGate nand;
};

#endif
