#ifndef NAND_GATE_H
#define NAND_GATE_H
#include "core/Gate.h"
class NANDGate : public Gate {
public:
    NANDGate();
    void evaluate() override;
};
#endif
